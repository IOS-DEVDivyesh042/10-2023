//
//  BtoD.swift
//  BaseXpertPro
//
//  Created by Manish Bhanushali on 20/10/23.
//

import UIKit

class BtoD: UIViewController {

    @IBOutlet weak var binaryTextField: UITextField!
        @IBOutlet weak var decimalLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        decimalLabel.layer.cornerRadius = 20
        decimalLabel.layer.borderColor = UIColor.yellow.cgColor
        decimalLabel.layer.borderWidth = 2
    }

        @IBAction func convertBinaryToDecimal(_ sender: UIButton) {
            if let binaryText = binaryTextField.text {
                if let decimalValue = binaryToDecimal(binaryText) {
                    decimalLabel.text = "Decimal: \(decimalValue)"
                } else {
                    decimalLabel.text = "Invalid binary input"
                }
            }
        }
        
        func binaryToDecimal(_ binary: String) -> Int? {
            if let decimalValue = Int(binary, radix: 2) {
                return decimalValue
            }
            return nil
        }
    }
