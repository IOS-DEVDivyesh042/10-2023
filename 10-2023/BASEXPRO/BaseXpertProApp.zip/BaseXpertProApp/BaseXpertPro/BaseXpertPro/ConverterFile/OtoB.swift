//
//  OtoB.swift
//  BaseXpertPro
//
//  Created by Manish Bhanushali on 20/10/23.
//

import UIKit

class OtoB: UIViewController {

    @IBOutlet weak var octalTextField: UITextField!
        @IBOutlet weak var binaryLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        binaryLabel.layer.cornerRadius = 20
        binaryLabel.layer.borderColor = UIColor.yellow.cgColor
        binaryLabel.layer.borderWidth = 2
        
        
    }

        @IBAction func convertOctalToBinary(_ sender: UIButton) {
            if let octalText = octalTextField.text, let octalValue = Int(octalText, radix: 8) {
                let binaryValue = octalToBinary(octalValue)
                binaryLabel.text = "Binary: " + binaryValue
            } else {
                binaryLabel.text = "Invalid octal input"
            }
        }
        
        func octalToBinary(_ octal: Int) -> String {
            return String(octal, radix: 2)
        }
    }


