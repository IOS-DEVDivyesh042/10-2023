//
//  OtoD.swift
//  BaseXpertPro
//
//  Created by Manish Bhanushali on 20/10/23.
//

import UIKit

class OtoD: UIViewController {

    @IBOutlet weak var octalTextField: UITextField!
       @IBOutlet weak var decimalLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        decimalLabel.layer.cornerRadius = 20
        decimalLabel.layer.borderColor = UIColor.yellow.cgColor
        decimalLabel.layer.borderWidth = 2
        
    }

       @IBAction func convertOctalToDecimal(_ sender: UIButton) {
           if let octalText = octalTextField.text, let decimalValue = octalToDecimal(octalText) {
               decimalLabel.text = "Decimal: \(decimalValue)"
           } else {
               decimalLabel.text = "Invalid octal input"
           }
       }
       
       func octalToDecimal(_ octal: String) -> Int? {
           if let decimalValue = Int(octal, radix: 8) {
               return decimalValue
           }
           return nil
       }
   }

