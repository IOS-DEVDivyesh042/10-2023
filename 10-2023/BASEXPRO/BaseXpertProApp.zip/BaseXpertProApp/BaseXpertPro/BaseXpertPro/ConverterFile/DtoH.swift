//
//  DtoH.swift
//  BaseXpertPro
//
//  Created by Manish Bhanushali on 20/10/23.
//

import UIKit

class DtoH: UIViewController {

    @IBOutlet weak var decimalTextField: UITextField!
        @IBOutlet weak var hexadecimalLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        hexadecimalLabel.layer.cornerRadius = 20
        hexadecimalLabel.layer.borderColor = UIColor.yellow.cgColor
        hexadecimalLabel.layer.borderWidth = 2
        
    }

        @IBAction func convertDecimalToHexadecimal(_ sender: UIButton) {
            if let decimalText = decimalTextField.text, let decimalValue = Int(decimalText) {
                let hexadecimalValue = decimalToHexadecimal(decimalValue)
                hexadecimalLabel.text = "Hexadecimal: 0x" + hexadecimalValue
            } else {
                hexadecimalLabel.text = "Invalid decimal input"
            }
        }
        
        func decimalToHexadecimal(_ decimal: Int) -> String {
            return String(format: "%X", decimal)
        }
    }
