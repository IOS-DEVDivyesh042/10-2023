//
//  HtoO.swift
//  BaseXpertPro
//
//  Created by Manish Bhanushali on 20/10/23.
//

import UIKit

class HtoO: UIViewController {

    @IBOutlet weak var hexadecimalTextField: UITextField!
        @IBOutlet weak var octalLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        octalLabel.layer.cornerRadius = 20
        octalLabel.layer.borderColor = UIColor.yellow.cgColor
        octalLabel.layer.borderWidth = 2
    }

        @IBAction func convertHexadecimalToOctal(_ sender: UIButton) {
            if let hexadecimalText = hexadecimalTextField.text {
                if let octalValue = hexadecimalToOctal(hexadecimalText) {
                    octalLabel.text = "Octal: " + octalValue
                } else {
                    octalLabel.text = "Invalid hexadecimal input"
                }
            }
        }
        
        func hexadecimalToOctal(_ hexadecimal: String) -> String? {
            if let decimalValue = Int(hexadecimal, radix: 16) {
                let octalValue = String(decimalValue, radix: 8)
                return octalValue
            }
            return nil
        }
    }
