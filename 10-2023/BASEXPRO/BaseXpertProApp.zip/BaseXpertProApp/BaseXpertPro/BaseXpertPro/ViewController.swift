//
//  ViewController.swift
//  BaseXpertPro
//
//  Created by Manish Bhanushali on 20/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    
    @IBOutlet weak var view4: UIView!
    
    @IBOutlet weak var view5: UIView!
    
    
    @IBOutlet weak var view6: UIView!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view5.layer.cornerRadius = 15
        view4.layer.cornerRadius = 15
        view3.layer.cornerRadius = 15
        view2.layer.cornerRadius = 15
        view1.layer.cornerRadius = 15
        view6.layer.cornerRadius = 15
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func btod(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "BtoD")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    @IBAction func dtoh(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "DtoH")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func hto0(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "HtoO")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    @IBAction func otob(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "OtoB")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    @IBAction func otod(_ sender: Any) {
        let nextvc = storyboard?.instantiateViewController(withIdentifier: "OtoD")
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    

}

